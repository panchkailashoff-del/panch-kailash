# Panch Kailash

A Journey Across Five Sacred Peaks — React + Vite site covering Mount
Kailash, Adi Kailash, Shrikhand Mahadev, Kinnaur Kailash and Manimahesh
Kailash.

## 1. Add your images

This project ships with **no binary image files** (they weren't included in
the source material). Put your six existing images into `public/images/`
using these **exact filenames** — the code already references them:

```
public/images/0db44277-5b9b-4617-9a13-0b1ba8492cb0.webp   ← homepage hero
public/images/eb384ae0-c0bb-4def-b511-190079473d48.webp   ← Kinnaur Kailash
public/images/panorama-bfce809f-706a-4f54-af98-49e4d6cae831.png  ← Manimahesh Kailash
public/images/911f1828-7225-4606-8fd5-f950170646ab.webp   ← Adi Kailash
public/images/1aebea2f-ed66-4843-80ef-f381f65cfe50.webp   ← Shrikhand Mahadev
public/images/388b155f-bb32-4cc2-ab13-f77765494af4.webp   ← Mount Kailash
```

You can drag-and-drop these straight into the folder on GitHub mobile web
(github.com in a browser, not the app) — go to `public/images/`, tap **Add
file → Upload files**.

## 2. Run locally (optional — Codespaces works great from a phone)

```bash
npm install
npm run dev      # local dev server
npm run build    # production build — must complete without errors
```

If you don't have a laptop, open this repo in **GitHub Codespaces**
(available from the green "Code" button, even from the GitHub mobile web
view) — it gives you a full terminal in the browser to run these commands.

## 3. Deploy to GitHub Pages (fully automatic, no CLI needed)

This repo includes `.github/workflows/deploy.yml`, which builds and deploys
the site automatically on every push to `main`. One-time setup:

1. On GitHub, go to your repo → **Settings → Pages**.
2. Under "Build and deployment", set **Source** to **GitHub Actions**.
3. Push (or upload) any change to `main` — the Actions tab will show the
   build running, then your site is live at:
   `https://panchkailashoff-del.github.io/panch-kailash/`

You do **not** need to run `npm run deploy` manually — the workflow handles
it. `vite.config.js` is already set with `base: "/panch-kailash/"` to match
this repository name; if you ever rename the repo, update that value too.

## 4. Project structure

```
src/
├── data/destinations.js   ← ALL destination content lives here
├── components/            ← reusable UI (Hero, Hotspot, StatusBanner, ...)
├── pages/                 ← routed pages, incl. shared DestinationPage
├── hooks/                 ← useLocalStorage, useReducedMotion
├── styles/                ← tokens.css (design tokens) + global.css
└── App.jsx / main.jsx
```

To add or edit a destination — status, cost, safety notes, sources — edit
`src/data/destinations.js` only. No component needs to change.

## 5. Keeping information current

Every dynamic fact (status, cost, permits) carries `lastVerified` and
`source` fields in `destinations.js`. When you have a newer official
notice, update those fields — the StatusBanner and destination pages pick
the change up automatically.
